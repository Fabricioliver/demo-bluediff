package com.qintess.blueidffclean.infrastructure;

import org.springframework.data.jpa.repository.JpaRepository;

import com.qintess.blueidffclean.domain.Produto;
import org.springframework.stereotype.Repository;
import java.util.List;

public interface ProdutoRepository extends JpaRepository<Produto, Long> {

    //List<Produto> findByNomeContainingIgnoreCase(String nome);

}