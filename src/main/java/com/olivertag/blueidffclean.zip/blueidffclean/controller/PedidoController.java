package com.qintess.blueidffclean.controller;

import com.qintess.blueidffclean.application.PedidoService;
import com.qintess.blueidffclean.domain.Pedido;
import com.qintess.blueidffclean.domain.Cliente;
import com.qintess.blueidffclean.domain.ItemPedido;
import com.qintess.blueidffclean.domain.Produto;
import com.qintess.blueidffclean.dto.PedidoRequest;
import com.qintess.blueidffclean.mapper.PedidoMapper;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/pedidos")
public class PedidoController {

    private final PedidoService pedidoService;

    public PedidoController(PedidoService pedidoService) {
        this.pedidoService = pedidoService;
    }

    @GetMapping("/listarTodos")
    public ResponseEntity<List<Pedido>> listarTodos() {
        return ResponseEntity.ok(pedidoService.listarTodos());
    }

    @PostMapping
    public ResponseEntity<Pedido> salvar(@RequestBody PedidoRequest pedidoRequest) {
        Pedido pedido = PedidoMapper.toEntity(pedidoRequest); // conversão aqui
        Pedido salvo = pedidoService.salvar(pedido);
        return new ResponseEntity<>(salvo, HttpStatus.CREATED);
    }


}
